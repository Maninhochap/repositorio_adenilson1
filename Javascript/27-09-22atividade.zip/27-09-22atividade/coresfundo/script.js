function selecionar(selecione){
        let cores = document.querySelector('.cores');
        let cor = selecione.value;
        cores.style.background = cor;

      }